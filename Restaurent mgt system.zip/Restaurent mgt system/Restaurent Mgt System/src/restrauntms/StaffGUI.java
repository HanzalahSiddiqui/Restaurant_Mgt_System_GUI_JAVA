/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restrauntms;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StaffGUI extends JFrame {
    private DefaultListModel<Staff> staffListModel;
    private JList<Staff> staffList;
    private JButton addButton;
    private JTextField nameTextField;
    private JTextField positionTextField;

    private Restaurant restaurant;

    public StaffGUI(Restaurant restaurant) {
        super("Staff Members");

        this.restaurant = restaurant;

        // Initialize staff list
        staffListModel = new DefaultListModel<>();
        staffList = new JList<>(staffListModel);
        JScrollPane staffScrollPane = new JScrollPane(staffList);
        staffScrollPane.setPreferredSize(new Dimension(150, 200));

        // Initialize buttons
        addButton = new JButton("Add");
        nameTextField = new JTextField(10);
        positionTextField = new JTextField(10);

        // Add action listeners
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameTextField.getText();
                String position = positionTextField.getText();
                Staff staff = new Staff(name, position);
                restaurant.addStaff(staff);
                staffListModel.addElement(staff);
                nameTextField.setText("");
                positionTextField.setText("");
            }
        });

        // Set layout
        JPanel mainPanel = new JPanel();
        mainPanel.add(staffScrollPane);
        mainPanel.add(new JLabel("Name:"));
        mainPanel.add(nameTextField);
        mainPanel.add(new JLabel("Position:"));
        mainPanel.add(positionTextField);
        mainPanel.add(addButton);
        getContentPane().add(mainPanel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

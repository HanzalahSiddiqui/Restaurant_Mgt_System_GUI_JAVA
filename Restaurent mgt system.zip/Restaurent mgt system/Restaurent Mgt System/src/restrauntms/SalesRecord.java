/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restrauntms;

import java.text.SimpleDateFormat;
import java.util.*;

public class SalesRecord {
    private Date date;
    private double totalSales;

    public SalesRecord(Date date, double totalSales) {
        this.date = date;
        this.totalSales = totalSales;
    }

    public Date getDate() {
        return date;
    }

    public double getTotalSales() {
        return totalSales;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setTotalSales(double totalSales) {
        this.totalSales = totalSales;
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateString = sdf.format(date);
        return dateString + " - $" + totalSales;
    }
}

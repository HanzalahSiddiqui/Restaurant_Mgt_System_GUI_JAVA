/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package restrauntms;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class SalesRecordGUI extends JFrame {
    private DefaultListModel<SalesRecord> salesRecordListModel;
    private JList<SalesRecord> salesRecordList;

    private Restaurant restaurant;

    public SalesRecordGUI(Restaurant restaurant) {
        super("Sales Records");

        this.restaurant = restaurant;

        // Initialize sales record list
        salesRecordListModel = new DefaultListModel<>();
        salesRecordList = new JList<>(salesRecordListModel);
        JScrollPane salesRecordScrollPane = new JScrollPane(salesRecordList);
        salesRecordScrollPane.setPreferredSize(new Dimension(300, 200));

        // Set layout
        JPanel mainPanel = new JPanel();
        mainPanel.add(salesRecordScrollPane);
        getContentPane().add(mainPanel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        updateSalesRecords();
    }

    public void updateSalesRecords() {
        salesRecordListModel.clear();
        for (SalesRecord record : restaurant.getSalesRecords()) {
            salesRecordListModel.addElement(record);
        }
    }
}
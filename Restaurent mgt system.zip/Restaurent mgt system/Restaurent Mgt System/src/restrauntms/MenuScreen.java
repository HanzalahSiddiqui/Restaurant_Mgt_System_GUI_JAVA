package restrauntms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MenuScreen extends JFrame {
    private JButton menuItemButton;
    private JButton staffButton;
    private JButton salesRecordButton;
    private JButton restaurantButton;


    private Restaurant restaurant;

    public MenuScreen(Restaurant restaurant) {
        super("Menu Screen");

        this.restaurant = restaurant;

        // Set UIManager for visual enhancements
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize buttons
        menuItemButton = new JButton("Menu Items");

        staffButton = new JButton("Staff Members");
        salesRecordButton = new JButton("Sales Records");
        restaurantButton = new JButton("Restaurant");
      

        // Set button styles and properties

        // ...

        // Add action listeners
        menuItemButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MenuItemGUI(restaurant);
            }
        });

   

        staffButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new StaffGUI(restaurant);
            }
        });

        salesRecordButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new SalesRecordGUI(restaurant);
            }
        });

        restaurantButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RestaurantGUI(restaurant);
            }
        });

    

        // Set layout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        mainPanel.add(menuItemButton, gbc);

        gbc.gridy++;
        mainPanel.add(staffButton, gbc);

        gbc.gridy++;
        mainPanel.add(salesRecordButton, gbc);

        gbc.gridy++;
        mainPanel.add(restaurantButton, gbc);

        getContentPane().add(mainPanel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}

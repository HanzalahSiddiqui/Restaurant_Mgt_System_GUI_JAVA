package restrauntms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MenuItemGUI extends JFrame {
    private DefaultListModel<MenuItem> menuListModel;
    private JList<MenuItem> menuList;
    private JButton addButton;
    private JTextField nameTextField;
    private JTextField priceTextField;

    private Restaurant restaurant;

    public MenuItemGUI(Restaurant restaurant) {
        super("Menu Items");

        this.restaurant = restaurant;

        // Set UIManager for visual enhancements
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize menu list
        menuListModel = new DefaultListModel<>();
        menuList = new JList<>(menuListModel);
        JScrollPane menuScrollPane = new JScrollPane(menuList);
        menuScrollPane.setPreferredSize(new Dimension(400, 300));

        // Initialize buttons
        addButton = new JButton("Add");
        nameTextField = new JTextField(15);
        priceTextField = new JTextField(15);

        // Set layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Add Menu Item"));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.LINE_START;
        constraints.insets = new Insets(5, 5, 5, 5);

        formPanel.add(new JLabel("Name:"), constraints);

        constraints.gridy = 1;
        formPanel.add(new JLabel("Price:"), constraints);

        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.weightx = 1.0;
        constraints.fill = GridBagConstraints.HORIZONTAL;

        formPanel.add(nameTextField, constraints);

        constraints.gridy = 1;
        formPanel.add(priceTextField, constraints);

        constraints.gridx = 2;
        constraints.gridy = 0;
        constraints.gridheight = 2;
        constraints.weightx = 0.0;
        constraints.fill = GridBagConstraints.NONE;

        formPanel.add(addButton, constraints);

        mainPanel.add(menuScrollPane, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.SOUTH);
        getContentPane().add(mainPanel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        // Add action listeners
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameTextField.getText();
                double price = Double.parseDouble(priceTextField.getText());
                MenuItem item = new MenuItem(name, price);
                restaurant.addMenuItem(item);
                menuListModel.addElement(item);
                nameTextField.setText("");
                priceTextField.setText("");
            }
        });
    }
}

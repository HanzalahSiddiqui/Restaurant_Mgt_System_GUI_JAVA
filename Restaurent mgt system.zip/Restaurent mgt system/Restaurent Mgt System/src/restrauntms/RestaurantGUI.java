package restrauntms;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class RestaurantGUI extends JFrame {
    private JButton createOrderButton;
    private DefaultListModel<MenuItem> menuListModel;
    private JList<MenuItem> menuList;
    private DefaultListModel<MenuItem> orderListModel;
    private JList<MenuItem> orderList;

    private Restaurant restaurant;
    private SalesRecordGUI salesRecordGUI;
    private Order currentOrder;

    public RestaurantGUI(Restaurant restaurant) {
        super("Restaurant");

        this.restaurant = restaurant;

        // Initialize components
        createOrderButton = new JButton("Create Order");
        menuListModel = new DefaultListModel<>();
        menuList = new JList<>(menuListModel);
        orderListModel = new DefaultListModel<>();
        orderList = new JList<>(orderListModel);

        // Create the SalesRecordGUI
        salesRecordGUI = new SalesRecordGUI(restaurant);

        // Set layout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel menuPanel = new JPanel(new BorderLayout());
        menuPanel.setBorder(BorderFactory.createTitledBorder("Menu"));
        menuPanel.add(new JScrollPane(menuList), BorderLayout.CENTER);

        JPanel orderPanel = new JPanel(new BorderLayout());
        orderPanel.setBorder(BorderFactory.createTitledBorder("Order"));
        orderPanel.add(new JScrollPane(orderList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(createOrderButton);

        mainPanel.add(menuPanel, BorderLayout.WEST);
        mainPanel.add(orderPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().add(mainPanel);

        // Set frame properties
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);

        // Add action listeners
        createOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ArrayList<MenuItem> items = new ArrayList<>();
                int[] selectedIndices = menuList.getSelectedIndices();
                for (int index : selectedIndices) {
                    items.add(menuListModel.getElementAt(index));
                }
                currentOrder = new Order(items);
                restaurant.getSalesRecords().add(new SalesRecord(currentOrder.getDate(), currentOrder.getTotalCost()));
                salesRecordGUI.updateSalesRecords(); // Update sales records in SalesRecordGUI
                updateOrderList(); // Update the order list
            }
        });

        updateMenu(); // Update the menu items initially
        updateOrderList(); // Update the order list initially
    }

    public void updateMenu() {
        menuListModel.clear();
        for (MenuItem item : restaurant.getMenu()) {
            menuListModel.addElement(item);
        }
    }

    public void updateOrderList() {
        orderListModel.clear();
        if (currentOrder != null) {
            for (MenuItem item : currentOrder.getItems()) {
                orderListModel.addElement(item);
            }
        }
    }
}
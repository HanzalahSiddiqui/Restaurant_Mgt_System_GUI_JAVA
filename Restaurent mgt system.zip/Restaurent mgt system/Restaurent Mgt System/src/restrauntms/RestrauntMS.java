package restrauntms;

import java.util.Date;
import javax.swing.SwingUtilities;

public class RestrauntMS {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
    public void run() {
        Restaurant restaurant = new Restaurant();
        MenuScreen menuScreen = new MenuScreen(restaurant);

        // Generate dummy menu items for testing
        MenuItem item1 = new MenuItem("Burger", 9.99);
        MenuItem item2 = new MenuItem("Pizza", 12.99);
        restaurant.addMenuItem(item1);
        restaurant.addMenuItem(item2);

      

        // Generate dummy staff members for testing
        Staff staff1 = new Staff("John Doe", "Chef");
        Staff staff2 = new Staff("Jane Smith", "Waiter");
        restaurant.addStaff(staff1);
        restaurant.addStaff(staff2);

        // Generate dummy sales records for testing
        Date date1 = new Date();
        Date date2 = new Date();
        Date date3 = new Date();
        SalesRecord record1 = new SalesRecord(date1, 50.0);
        SalesRecord record2 = new SalesRecord(date2, 75.0);
        SalesRecord record3 = new SalesRecord(date3, 100.0);
        restaurant.getSalesRecords().add(record1);
        restaurant.getSalesRecords().add(record2);
        restaurant.getSalesRecords().add(record3);
    }
});
    }
    
}

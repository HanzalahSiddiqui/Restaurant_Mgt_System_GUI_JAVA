package restrauntms;

import java.util.*;
import javax.swing.*;

public class Order {
    private List<MenuItem> items;
    private double totalCost;
    private Date date;

    public Order(List<MenuItem> items) {
        this.items = items;
        this.totalCost = calculateTotalCost();
        this.date = new Date(); // Set the current date and time as the order date
    }

    private double calculateTotalCost() {
        double total = 0.0;
        for (MenuItem item : items) {
            total += item.getPrice();
        }
        return total;
    }

    public List<MenuItem> getItems() {
        return items;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public Date getDate() {
        return date;
    }

    public void setItems(List<MenuItem> items) {
        this.items = items;
        this.totalCost = calculateTotalCost();
    }

    public void printReceipt() {
        StringBuilder receipt = new StringBuilder("Receipt:\n");
        for (MenuItem item : items) {
            receipt.append(item.getName()).append(" - $").append(item.getPrice()).append("\n");
        }
        receipt.append("Total Cost: $").append(totalCost).append("\n");
        JOptionPane.showMessageDialog(null, receipt.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);
    }
}
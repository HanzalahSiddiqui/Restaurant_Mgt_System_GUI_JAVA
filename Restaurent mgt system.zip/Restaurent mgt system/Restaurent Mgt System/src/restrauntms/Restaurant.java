
package restrauntms;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;


public class Restaurant {
    private ArrayList<MenuItem> menu;
    private ArrayList<Staff> staff;
    private ArrayList<SalesRecord> salesRecords;

    public Restaurant() {
        this.menu = new ArrayList<>();
        this.staff = new ArrayList<>();
        this.salesRecords = new ArrayList<>();
    }

    public ArrayList<MenuItem> getMenu() {
        return menu;
    }

    public ArrayList<Staff> getStaff() {
        return staff;
    }

    public ArrayList<SalesRecord> getSalesRecords() {
        return salesRecords;
    }

    public void addMenuItem(MenuItem item) {
        menu.add(item);
    }
    public void addStaff(Staff member) {
        staff.add(member);
    }

    public void createOrder(ArrayList<MenuItem> items) {
        Order order = new Order(items);
        order.printReceipt();
        generateSalesRecord(new Date(), order.getTotalCost());
    }

    public void sendReminderToChefs() {
        StringBuilder reminder = new StringBuilder("Reminder: Order ingredients!\n");
        for (Staff staffMember : staff) {
            if (staffMember.getPosition().equals("Chef")) {
                reminder.append("To: ").append(staffMember.getName()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, reminder.toString(), "Reminder", JOptionPane.INFORMATION_MESSAGE);
    }

    public void generateSalesRecord(Date date, double totalSales) {
        SalesRecord record = new SalesRecord(date, totalSales);
        salesRecords.add(record);
        JOptionPane.showMessageDialog(null, "Sales record generated.", "Sales Record", JOptionPane.INFORMATION_MESSAGE);
    }
}
